// Точка сборки Three.js в глобальную переменную THREE (для автономного index.html).
// ВАЖНО: вход именно ESM (export *), чтобы esbuild взял three.module.js —
// браузерную сборку без ссылок на process/require из Node.
// esbuild: --bundle --minify --format=iife --global-name=THREE  =>  var THREE = (...)
export * from 'three';
