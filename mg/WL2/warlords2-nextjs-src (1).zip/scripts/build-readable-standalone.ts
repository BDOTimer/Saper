/**
 * Сборка ЧИТААЕМОЙ автономной версии Warlords II (single-file index.html).
 *
 * Пайплайн:
 *  1. TypeScript -> JavaScript (без минификации, комментарии сохраняются) через TS API
 *  2. Rollup: склейка модулей в один IIFE, three остаётся внешним (глобальная THREE)
 *  3. Prettier: красивое форматирование итогового кода
 *  4. Сборка index.html: шаблон + three.min.js (сжатая библиотека) + игровой код
 *
 * Результат: download/warlords2-standalone/index.html и public/standalone/index.html
 */

import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'fs';
import { join, relative, dirname } from 'path';
import ts from 'typescript';

const root = '/home/z/my-project';
const buildDir = join(root, '.build/readable');
const outDirs = [join(root, 'download/warlords2-standalone'), join(root, 'public/standalone')];

// ---------- 1. Транспиляция TS -> JS с сохранением комментариев ----------

function walk(dir: string, acc: string[] = []): string[] {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p, acc);
    else if (p.endsWith('.ts')) acc.push(p);
  }
  return acc;
}

const srcDirs = [join(root, 'src/lib/game'), join(root, 'src/standalone')];
const files = srcDirs.flatMap((d) => walk(d));

for (const file of files) {
  const src = readFileSync(file, 'utf8');
  let js = ts.transpileModule(src, {
    fileName: file,
    compilerOptions: {
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
      removeComments: false,
      useDefineForClassFields: false,
    },
  }).outputText;
  // Three.js в автономной сборке — глобальная переменная THREE (ЧАСТЬ 3 файла).
  // Убираем namespace-импорт, чтобы rollup не генерировал interop-обёртку,
  // а код читался как обычные обращения THREE.Scene, THREE.Vector3 и т.д.
  js = js.replace(/^\s*import \* as (\w+) from ['"]three['"];?\s*$/gm, '');
  // Пустой экспорт точки входа не нужен внутри IIFE
  js = js.replace(/^\s*export \{\};?\s*$/gm, '');
  const outPath = join(buildDir, relative(root, file).replace(/\.ts$/, '.js'));
  mkdirSync(dirname(outPath), { recursive: true });
  writeFileSync(outPath, js);
}
console.log(`[1/4] TS->JS: ${files.length} файлов (комментарии сохранены)`);

// ---------- 2. Rollup: склейка в один IIFE ----------

const { rollup } = await import('rollup');

const bundle = await rollup({
  input: join(buildDir, 'src/standalone/main.js'),
  external: (id) => id === 'three',
  treeshake: false,
  output: {
    format: 'iife',
    name: 'Warlords',
    globals: { three: 'THREE' },
    indent: '  ',
  },
});
const { output } = await bundle.generate({
  format: 'iife',
  name: 'Warlords',
  globals: { three: 'THREE' },
  indent: '  ',
});
await bundle.close();
let gameJs = output[0].code;
console.log(`[2/4] Rollup: ${Math.round(gameJs.length / 1024)} KB`);

// Порядок модулей в бандле (для контроля нумерации баннеров)
const anchors: [string, string][] = [
  ['types', 'МОДУЛЬ 1 · TYPES'],
  ['rng', 'МОДУЛЬ 2 · RNG'],
  ['board', 'МОДУЛЬ 3 · BOARD'],
  ['combat', 'МОДУЛЬ 4 · COMBAT'],
  ['game', 'МОДУЛЬ 5 · GAME'],
  ['renderer', 'МОДУЛЬ 6 · RENDERER'],
  ['audio', 'МОДУЛЬ 7 · AUDIO'],
  ['ai', 'МОДУЛЬ 8 · AI'],
  ['ui', 'МОДУЛЬ 9 · UI'],
  ['main', 'МОДУЛЬ 10 · MAIN'],
];
const order = anchors
  .map(([name, a]) => ({ name, pos: gameJs.indexOf(a) }))
  .filter((o) => o.pos >= 0)
  .sort((a, b) => a.pos - b.pos)
  .map((o) => o.name);
console.log('      порядок модулей:', order.join(' -> '));

// ---------- 3. Prettier: форматирование ----------

const prettier = await import('prettier');
gameJs = await prettier.format(gameJs, {
  parser: 'babel',
  singleQuote: true,
  printWidth: 100,
  tabWidth: 2,
});
// Стартовая строка игрового скрипта
const gameHeader =
  '// ⚔ WARLORDS II — игровой код (модули 1–10 читаются сверху вниз)\n\n';
gameJs = gameHeader + gameJs;
console.log(`[3/4] Prettier: ${Math.round(gameJs.length / 1024)} KB`);
writeFileSync(join(root, '.build/game.readable.js'), gameJs);

// ---------- 4. Сборка index.html ----------

const tpl = readFileSync(join(root, 'scripts/standalone-template.html'), 'utf8');
let threeJs = readFileSync(join(root, '.build/three.min.js'), 'utf8');

// Защита от преждевременного закрытия тега <script>
const esc = (s: string) => s.replaceAll('</script', '<\\/script');
threeJs = esc(threeJs);
gameJs = esc(gameJs);

const html = tpl
  .replace('/*__THREE__*/', () => threeJs)
  .replace('/*__GAME__*/', () => gameJs);

if (/<script>\/\*__/.test(html)) {
  throw new Error('Плейсхолдеры не заменены — проверьте шаблон');
}

for (const dir of outDirs) {
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'index.html'), html);
}
console.log(`[4/4] index.html: ${(html.length / 1024).toFixed(0)} KB -> download/ + public/standalone/`);
