#!/bin/bash
# Сборка автономной single-file версии Warlords II (download/warlords2-standalone/index.html).
# Итоговый index.html — ЧИТАЕМЫЙ: красивые стили и разметка с комментариями,
# игровой код собран rollup-ом без минификации с сохранением всех комментариев.
# Сжата только библиотека Three.js (ЧАСТЬ 3 файла) — её читать не нужно.
set -euo pipefail
cd /home/z/my-project
mkdir -p .build

echo "[1/2] esbuild: Three.js -> сжатая IIFE (глобальная переменная THREE)..."
bunx esbuild scripts/three-global.js \
  --bundle --minify --format=iife --global-name=THREE --charset=utf8 \
  --outfile=.build/three.min.js

echo "[2/2] Читаемая сборка: TS->JS (комментарии) -> rollup -> prettier -> index.html..."
bun scripts/build-readable-standalone.ts

echo "Готово: download/warlords2-standalone/index.html"
