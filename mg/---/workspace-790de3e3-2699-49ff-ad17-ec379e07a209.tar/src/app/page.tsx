export default function Home() {
  return (
    <iframe
      src="/monopoly.html"
      title="Монополия — Классика"
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        border: 'none',
        backgroundColor: '#0a0a14',
      }}
      allow="autoplay"
    />
  )
}
